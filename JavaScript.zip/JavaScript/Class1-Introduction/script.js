console.log("external js is loazzzzded");
// console.log(document.querySelector("h1"))
alert("welconme");