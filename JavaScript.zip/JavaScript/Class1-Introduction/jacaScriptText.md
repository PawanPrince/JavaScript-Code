*) JavaScript:

*) Features of Java script:
1) Interpreted language:
2) Synchronous in Nature:
3) Loosely / weakly typed language:  
4) Dynamically typed language:
5) Clint-side language: Initially js is clint-side lang but now its also works as server side language.
==================================================================================================
we can apply js in 2 ways.
=====================================================================================================

*) TOKENS-

1) Keywords:
2) Identifiers:
3) Literals / Values: 
4) Operatos:

===============================================================================================
*) Variables: 

1) 3 ways keywords:

var
let
const

2) 2 types :

*) Global:

we can make by using 
var
let
const

*) Local

=============================================================================================

*) DataTypes

1) Primitives 

number
string
boolean
undefined
null
Bigint
Symbol

2) Non- Primitives

Arrays
Objects
Functions

* ) Equals in JavaScript

// == loosely 
// === strictily comarison



* does browers read js language?
* can we miss semi colomn in js?
* css full form and what does it mean?
* css speciecty


