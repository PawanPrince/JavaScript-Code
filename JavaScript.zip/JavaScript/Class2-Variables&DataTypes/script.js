
// var a;
// a = 10;
// console.log(a);

// var a;
// a = 20;
// console.log(a);

// var b;
// b = 65760;
// console.log(b);

// var b;
// b = 850;
// console.log(b);

// // Now we see LET and CONST:

// // LET : we can't redeclared & reinitilied IN let var.

// let m;
// m = "helloo";
// console.log(m);

// // CONSTANT: in const we can't leave in declaration mode we have to initilied  at same time


// const q = "pawn";
// console.log(q);





//!  DATATYPES

var n1 = 10;
console.log(typeof n1); // number

console.log(typeof typeof n1); // String

var n2 = "pawannn";
console.log(n2);
console.log(typeof  n2);

var n3 = true;
console.log(n3);
console.log(typeof  n3);

var n4 = undefined
console.log(n4);
console.log(typeof n4);

var n5 = null
console.log(n5);
console.log(typeof n5);

var n6 = 9999999999999999999999n
var n7 = 79n

console.log(n6);
console.log(n7);
console.log(typeof n6);
console.log(typeof n7);


var s1 = Symbol("Javascript")
var s2 = Symbol("Javascript")

console.log(s1)
console.log(s2)
console.log(typeof s1)
console.log( s1 == s2)
// == loosely 
// === strictily comarison
console.log( s1 === s2)
console.log(s1);
